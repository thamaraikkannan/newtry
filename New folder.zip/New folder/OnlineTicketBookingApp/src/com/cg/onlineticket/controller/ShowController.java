package com.cg.onlineticket.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



import com.cg.onlineticket.bean.DetailsBean;
import com.cg.onlineticket.exception.TicketException;
import com.cg.onlineticket.service.ShowService;
import com.cg.onlineticket.service.ShowServiceImpl;


/**
 * Servlet implementation class ShowController
 */
@WebServlet("/ShowController")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       ShowService service;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        service = new ShowServiceImpl();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(true);
		String action=request.getParameter("action");
		if("index".equals(action)){
			try {
				ArrayList<DetailsBean> list = service.getAllData();
				session.setAttribute("list", list);
				RequestDispatcher dispatch=request.getRequestDispatcher("showDetails.jsp");
				dispatch.forward(request,response);
			} catch (TicketException e) {
				session.setAttribute("error", e.getMessage());
				response.sendRedirect("error.jsp");
			}
		}
		if("book".equals(action)){
            String showid = request.getParameter("sid");
            try{
                ArrayList<DetailsBean>list = service.getAllData();
                session.setAttribute("list", list);
                session.setAttribute("showid", showid);
                RequestDispatcher dispatch = request.getRequestDispatcher("bookNow.jsp");
                dispatch.forward(request, response);
            }
            catch(TicketException e){
                session.setAttribute("error", e.getMessage());
                response.sendRedirect("error.jsp");
            }
            
        }
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
