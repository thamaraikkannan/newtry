package com.cg.onlineticket.exception;

public class TicketException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 9209244801807345131L;
	String message;
	
	public TicketException(String msg) {
	
		this.message = msg;
	}
	@Override
	public String getMessage()
	{
		return message;
	}

}
