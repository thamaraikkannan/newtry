package com.cg.onlineticket.bean;

import java.sql.Date;

public class DetailsBean {
	
	private String ShowId;
	private String ShowName;
	private String Location;
	private Date showDate;
	private int AvSeats;
	private int PriceTicket;
	private String CustomerName;
	private long MobileNumber;
	private int No_of_Seats;
	public String getShowId() {
		return ShowId;
	}
	public void setShowId(String showId) {
		ShowId = showId;
	}
	public String getShowName() {
		return ShowName;
	}
	public void setShowName(String showName) {
		ShowName = showName;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public Date getShowDate() {
		return showDate;
	}
	public void setShowDate(Date showDate) {
		this.showDate = showDate;
	}
	public int getAvSeats() {
		return AvSeats;
	}
	public void setAvSeats(int avSeats) {
		AvSeats = avSeats;
	}
	public int getPriceTicket() {
		return PriceTicket;
	}
	public void setPriceTicket(int priceTicket) {
		PriceTicket = priceTicket;
	}
	
	
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public long getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		MobileNumber = mobileNumber;
	}
	public int getNo_of_Seats() {
		return No_of_Seats;
	}
	public void setNo_of_Seats(int no_of_Seats) {
		No_of_Seats = no_of_Seats;
	}
	
	@Override
	public String toString() {
		return "DetailsBean [ShowId=" + ShowId + ", ShowName=" + ShowName
				+ ", Location=" + Location + ", showDate=" + showDate
				+ ", AvSeats=" + AvSeats + ", PriceTicket=" + PriceTicket
				+ ", CustomerName=" + CustomerName + ", MobileNumber="
				+ MobileNumber + ", No_of_Seats=" + No_of_Seats + "]";
	}
	
	public DetailsBean(String showId, String showName, String location,
			Date showDate, int avSeats, int priceTicket, String customerName,
			long mobileNumber, int no_of_Seats) {
		super();
		ShowId = showId;
		ShowName = showName;
		Location = location;
		this.showDate = showDate;
		AvSeats = avSeats;
		PriceTicket = priceTicket;
		CustomerName = customerName;
		MobileNumber = mobileNumber;
		No_of_Seats = no_of_Seats;
	}
	public DetailsBean() {
		super();
		
	}
	
	
	

}
