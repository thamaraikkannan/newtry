package com.cg.onlineticket.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.onlineticket.exception.TicketException;

public class DBUtil {
	
	static Connection con;
	static String errorMessage;
	static
	{
		try{
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/jdbc/TestDS");
			con = source.getConnection();
		}catch(NamingException | SQLException e) {
			try {
				throw new TicketException(e.getMessage());
			} catch (TicketException e1) {
				
				errorMessage = e1.getMessage();
			}
		}
	}
	public static Connection getConnect()
	{
		return con;
	}

}
