package com.cg.onlineticket.service;

import java.util.ArrayList;

import com.cg.onlineticket.bean.DetailsBean;
import com.cg.onlineticket.dao.ShowDao;
import com.cg.onlineticket.dao.ShowDaoImpl;
import com.cg.onlineticket.exception.TicketException;

public class ShowServiceImpl implements ShowService{
	
	ShowDao dao;
	 public ShowServiceImpl()
	 {
		 dao=new ShowDaoImpl();
	 }

	@Override
	public ArrayList<DetailsBean> getAllData() throws TicketException {
		// TODO Auto-generated method stub
		return dao.getAllData();
	}

	@Override
	public DetailsBean bookTicket(String ShowId, int AvSeats)
			throws TicketException {
		// TODO Auto-generated method stub
		return dao.bookTicket(ShowId, AvSeats);
	}

}
