package com.cg.onlineticket.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;



import com.cg.onlineticket.util.DBUtil;
import com.cg.onlineticket.bean.DetailsBean;
import com.cg.onlineticket.exception.TicketException;


public class ShowDaoImpl implements ShowDao {
	
	Connection con;
	public ShowDaoImpl()
	{
		con=DBUtil.getConnect();
	}

	@Override
	public ArrayList<DetailsBean> getAllData() throws TicketException {
		
		ArrayList<DetailsBean> list = new ArrayList<DetailsBean>();
		String sql="select showname,location,showdate,priceticket,avseats from showdetails";
		try{
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(sql);
			while(rst.next())
			{
				DetailsBean bean = new DetailsBean();
				bean.setShowName(rst.getString(1));
				bean.setLocation(rst.getString(2));
				bean.setShowDate(rst.getDate(3));
				bean.setPriceTicket(rst.getInt(4));
				bean.setAvSeats(rst.getInt(5));
				list.add(bean);
			}
			if(list.size()==0) throw new TicketException("No data found");
		}catch(SQLException e)
		{
			throw new TicketException("Error while database interaction:::"
					+ e.getMessage());
		}
		
		return list;
	}


	@Override
	public DetailsBean bookTicket(String ShowId, int AvSeats) throws TicketException {
		
		DetailsBean bean = new DetailsBean();
		String sql="update showdetails set avseats=? where showname=?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, bean.getAvSeats());
			pstmt.setString(2, bean.getShowName());
			int row=pstmt.executeUpdate();
			if(row==1)
			{
				bean.setCustomerName(bean.getCustomerName());
				bean.setMobileNumber(bean.getMobileNumber());
				bean.setNo_of_Seats(bean.getNo_of_Seats());
				
			}
			else{
				throw new TicketException("unable to update the salary");
			}
		} catch (SQLException e) {
			
			throw new TicketException(e.getMessage());
		}
		
	return bean;
}

}
