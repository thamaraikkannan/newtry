package com.cg.onlineticket.dao;

import java.util.ArrayList;

import com.cg.onlineticket.bean.DetailsBean;
import com.cg.onlineticket.exception.TicketException;

public interface ShowDao {
	
	ArrayList<DetailsBean> getAllData() throws TicketException;
	DetailsBean bookTicket(String ShowId,int AvSeats) throws TicketException;
}
