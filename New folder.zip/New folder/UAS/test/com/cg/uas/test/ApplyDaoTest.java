package com.cg.uas.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.dao.ApplyDao;
import com.cg.uas.dao.ApplyDaoImpl;
import com.cg.uas.exception.ApplicantException;

public class ApplyDaoTest {

	static ApplyDao applyDao;
	static ApplicantBean applicant;
	
	@BeforeClass
	public static void init(){
		applyDao = new ApplyDaoImpl();
		applicant = new ApplicantBean();
	}
	
	@Test
	public void testaddApplicantDetails() throws ApplicantException{
		applicant.setfName("David");
		applicant.setlName("Billa");
		applicant.setContactNo(9876546541l);
		applicant.setEmail("david_billa@gmail.com");
		applicant.setAggregate(89.2f);
		applicant.setStream("Computer Science");
		int id = applyDao.addApplicantDetails(applicant);
		assertTrue(id > 0);
	}
	
	@Test
	public void testgetApplicantDetails() throws ApplicantException{
		applicant.setfName("David");
		applicant.setlName("Billa");
		applicant.setContactNo(9876546541l);
		applicant.setEmail("david_billa@gmail.com");
		applicant.setAggregate(89.2f);
		applicant.setStream("Computer Science");
		int id = applyDao.addApplicantDetails(applicant);
		applicant = applyDao.getApplicantDetails(id);
		assertEquals(id,applicant.getApplyId());
	}
	
}
