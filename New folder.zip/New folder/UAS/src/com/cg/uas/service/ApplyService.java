package com.cg.uas.service;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.exception.ApplicantException;

public interface ApplyService {

	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applicantID) throws ApplicantException;
	public boolean isValidApplicant(ApplicantBean applicant) throws ApplicantException;
}
