package com.cg.uas.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.dao.ApplyDao;
import com.cg.uas.dao.ApplyDaoImpl;
import com.cg.uas.exception.ApplicantException;

public class ApplyServiceImpl implements ApplyService{
	
	private ApplyDao applydao = new ApplyDaoImpl();

	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		int id = 0;
		id = applydao.addApplicantDetails(applicant);
		return id;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {
		ApplicantBean applicant = null;
		applicant = applydao.getApplicantDetails(applicantID);
		return applicant;
	}

	@Override
	public boolean isValidApplicant(ApplicantBean applicant)
			throws ApplicantException {
		
		List<String> validationErrors = new ArrayList<String>();

		//will call Validate contactNo
 		if(!(isValidContactNo(applicant.getContactNo()))){
			validationErrors.add("\n Contact number should be 10 numbers \n" );
		}
		//will call Validate FirstName(String fName)
		if(!(isValidfName(applicant.getfName()))) {
			validationErrors.add("\n First Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		//Validate LastName(String lName)
				if(!(isValidlName(applicant.getlName()))) {
					validationErrors.add("\n Last Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating Stream(String Stream)
		if(!(isValidStream(applicant.getStream()))){
			validationErrors.add("\n The Stream must be Greater than 5 Characters \n" );
		}
		
		//Validating Email (string email)
		if(!(isValidEmailAddress(applicant.getEmail()))){
			validationErrors.add("\n Email Should Be Greater Than 5 Characters and @ should come in middle\n");
		}
	
 		//Validating Aggregate(float aggregate)
 		if(!(isValidAggregate(applicant.getAggregate()))){
			validationErrors.add("\n Aggregate Should be a float Number \n" );
		}
		
 		
 		
		if(!validationErrors.isEmpty())
			throw new ApplicantException(validationErrors +"");
		return false;
	}

	

	private boolean isValidContactNo(long contactNo) {

		return (contactNo > 999999999);
	}

	private boolean isValidAggregate(float aggregate) {

		return (aggregate > 0);
	}

	private boolean isValidStream(String stream) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(stream);
		return nameMatcher.matches();
	
	}

	private boolean isValidfName(String getfName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getfName);
		return nameMatcher.matches();
		
	}

	private boolean isValidlName(String getlName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getlName);
		return nameMatcher.matches();
		
	}
	public boolean isValidEmailAddress(String getEmail){
		Pattern namePattern=Pattern.compile("\\b[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b");
		Matcher nameMatcher=namePattern.matcher(getEmail);
		return nameMatcher.matches();
	}
	
	public boolean isValidAmount(double amount){
		return (amount>0);
	}
	public boolean validateapplyId(String applyId) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(applyId);
		
		if(idMatcher.matches())
			return true;
		else
			return false;
	}

}
