package com.cg.uas.dao;

public interface QueryMapper {
	
	public static String INSERT_QUERY = "insert into candidate_detail values(apply_id_seq.nextval,?,?,?,?,?,?)";
	
	public static String SEQUENCE_QUERY = "select apply_id_seq.currval from dual";

	public static String SELECT_QUERY = "select applyid,firstname,lastname,contactno,stream,aggregate,email from candidate_detail where applyid=?";
}
