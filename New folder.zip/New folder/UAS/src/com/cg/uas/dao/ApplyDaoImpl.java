package com.cg.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.uas.util.DBConnection;
import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.exception.ApplicantException;

public class ApplyDaoImpl implements ApplyDao{
	private Logger logger =Logger.getLogger(ApplyDaoImpl.class);
	
	public ApplyDaoImpl()
	{
		PropertyConfigurator.configure("resources/log4j.properties");
	}


	@Override
	public int addApplicantDetails(ApplicantBean applicant)
			throws ApplicantException {
		int applyId=-1;

		try{
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.INSERT_QUERY);
			pstmt.setString(1, applicant.getfName());
			pstmt.setString(2, applicant.getlName());
			pstmt.setLong(3, applicant.getContactNo());
			pstmt.setString(4, applicant.getEmail());
			pstmt.setFloat(5, applicant.getAggregate());
			pstmt.setString(6, applicant.getStream());
			int result = pstmt.executeUpdate();
			if(result == 0){
				logger.error("unable to insert record ");
				throw new ApplicantException("insert Fail");
			}
			pstmt = con.prepareStatement(QueryMapper.SEQUENCE_QUERY);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				applyId=rst.getInt(1);
			}
			else
			{
				logger.error("Unable to fetch sequence");
				throw new ApplicantException("Unable to fetch Sequence");
			}
			con.close();
		}catch(SQLException e)
		{
			applyId = -1;
			logger.error("SQL ERROR"+e.getMessage());
			throw new ApplicantException(e.getMessage());
			
		}
		logger.info("Applicant Details Successfully Added");
		return applyId;
	}

	@Override
	public ApplicantBean getApplicantDetails(long applicantID)
			throws ApplicantException {
		ApplicantBean applicant = new ApplicantBean();
		
		try{
			Connection con = DBConnection.getConnection();
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.SELECT_QUERY);
			pstmt.setLong(1, applicantID);
			ResultSet rst = pstmt.executeQuery();
			if(rst.next())
			{
				applicant.setApplyId(rst.getLong(1));
				applicant.setfName(rst.getString(2));
				applicant.setlName(rst.getString(3));
				applicant.setContactNo(rst.getLong(4));
				applicant.setStream(rst.getString(5));
				applicant.setAggregate(rst.getFloat(6));
				applicant.setEmail(rst.getString(7));
				
			}
			else
			{
				throw new ApplicantException("Id not Found");
			}
			con.close();
			}
			catch(SQLException e)
			{
				logger.error("SQL ERROR"+e.getMessage());
				throw new ApplicantException(e.getMessage());
			}
		logger.info("Applicant details for the given Apply id was Sucessfully viewed");
		return applicant;
	}


}
