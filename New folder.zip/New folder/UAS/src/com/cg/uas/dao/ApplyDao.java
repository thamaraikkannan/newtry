package com.cg.uas.dao;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.exception.ApplicantException;

public interface ApplyDao {

	public int addApplicantDetails(ApplicantBean applicant) throws ApplicantException;
	public ApplicantBean getApplicantDetails(long applicantID) throws ApplicantException;
}
