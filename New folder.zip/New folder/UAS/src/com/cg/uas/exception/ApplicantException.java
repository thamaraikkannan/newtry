package com.cg.uas.exception;

public class ApplicantException extends Exception{

 
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ApplicantException(String message)
	{
		
		super(message);
	}
}
