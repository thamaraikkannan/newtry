package com.cg.uas.pl;

import java.util.Scanner;

import com.cg.uas.bean.ApplicantBean;
import com.cg.uas.exception.ApplicantException;
import com.cg.uas.service.ApplyServiceImpl;

public class Client {

	private static Scanner sc;
	
	public static void main(String[] args) {
		
		sc = new Scanner(System.in);
		ApplyServiceImpl service = new ApplyServiceImpl();
		ApplicantBean applicant = new ApplicantBean();
		while(true)
		{
			System.out.println("*******************Admission System***************");
			System.out.println("Select an operation");
			System.out.println("1. Enter Details");
			System.out.println("2. View Details based on Applicant Id");
			System.out.println("0. Exit");
			System.out.println("*******************");
			System.out.println("Please enter a choice:");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 0:
				System.out.println("Thank you for applying !!");
				System.exit(0);
			break;
			case 1:
				sc.nextLine();
				System.out.println("Enter First Name : ");
				String fName = sc.next();
				System.out.println("Enter Last Name : ");
				String lName = sc.next();
				System.out.println("Enter Contact Number : ");
				long ContactNo = sc.nextLong();
				System.out.println("Enter email : ");
				String email = sc.next();
				System.out.println("Enter Stream : ");
				String stream = sc.next();
				System.out.println("Enter Aggregate in qualifying exam : ");
				Float aggregate= sc.nextFloat();
				applicant.setfName(fName);
				applicant.setlName(lName);
				applicant.setContactNo(ContactNo);
				applicant.setEmail(email);
				applicant.setStream(stream);
				applicant.setAggregate(aggregate);
				try{
					service.isValidApplicant(applicant);
					int id = service.addApplicantDetails(applicant);
					System.out.println("Thank you "+fName+" "+lName+" your unique Id is "+id+" we will contact you shortly.");
				}
				catch(ApplicantException e){
					System.out.println(e);
				}
				break;
			case 2:
				System.out.println("Enter the Applicant Id .: ");
				int id1 = sc.nextInt();
				try{
					applicant = service.getApplicantDetails(id1);
					System.out.println("Id = "+applicant.getApplyId());
					System.out.println("First Name = "+applicant.getfName());
					System.out.println("Last Name = "+applicant.getlName());
					System.out.println("Contact No. = "+applicant.getContactNo());
					System.out.println("Stream = "+applicant.getStream());
					System.out.println("Aggregate= "+applicant.getAggregate());
					System.out.println("Email = "+applicant.getEmail());
				}
				catch(ApplicantException e){
					System.out.println("Sorry no details found!!");
				}
				break;
			
			}
		}

	}

}
