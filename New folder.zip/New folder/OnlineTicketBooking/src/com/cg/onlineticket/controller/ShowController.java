package com.cg.onlineticket.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.onlineticket.bean.ShowBean;
import com.cg.onlineticket.exception.ShowException;
import com.cg.onlineticket.service.IShowService;
import com.cg.onlineticket.service.ShowServiceImpl;

/**
 * Servlet implementation class ShowController
 */
@WebServlet("*.obj")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		ShowBean bean = new ShowBean();
		IShowService service = new ShowServiceImpl();
		String path=request.getServletPath().trim();
		
		String target="";
		switch(path)
		{
		case "/viewall.obj" :
			try {
				List<ShowBean> list = service.viewAllDetails();
				request.setAttribute("list", list);
				target="showDetails.jsp";
			} catch (ShowException e) {
				request.setAttribute("error",e.getMessage());
				target="error.jsp";
			}
			break;
			
		case "/Home.obj":
			target = "index.jsp";
			break;
			
		case "/bookNow.obj":
            String sname=request.getParameter("sname").trim();
            int sticket=Integer.parseInt(request.getParameter("sticket").trim());
            int qty=Integer.parseInt(request.getParameter("qty").trim());
            bean.setShowName(sname);
            bean.setPriceTicket(sticket);
            bean.setAvailableSeats(qty);
            request.setAttribute("bean", bean);
            target="bookNow.jsp";
            break;
            
            
        case "/update.obj":
            try{
            int q1=Integer.parseInt(request.getParameter("userqty").trim());
            int q2=Integer.parseInt(request.getParameter("qty").trim());
            int quantity=q2-q1;
            sname = request.getParameter("sname");
            
            int price=Integer.parseInt(request.getParameter("sticket"));
            String name=request.getParameter("cname").trim();
            String phone=request.getParameter("phone").trim();
            
            boolean flag=service.updateSeats(sname, quantity);
        
            if(flag==true)
            {
            	int amt=q1*price;
            	request.setAttribute("phone", phone);
            	request.setAttribute("cname", name);
            	request.setAttribute("sname", sname);
            	request.setAttribute("amt", amt);
                request.setAttribute("flag", flag);
                request.setAttribute("q1", q1);
                target="success.jsp";
            }
            else
            {
                request.setAttribute("error", "sorry not updated");
                target="error.jsp";
            }
            
            }
            catch(ShowException e)
            {
                request.setAttribute("error", e.getMessage());
                target = "error.jsp";
            }
            break;
		}
		RequestDispatcher rd = request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
