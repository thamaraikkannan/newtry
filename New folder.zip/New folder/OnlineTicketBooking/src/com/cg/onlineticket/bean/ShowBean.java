package com.cg.onlineticket.bean;

import java.time.LocalDate;

public class ShowBean {

	private int showId;
	private String showName;
	private String location;
	private LocalDate showDate;
	private int availableSeats;
	private int priceTicket;
	public int getShowId() {
		return showId;
	}
	public void setShowId(int showId) {
		this.showId = showId;
	}
	public String getShowName() {
		return showName;
	}
	public void setShowName(String showName) {
		this.showName = showName;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalDate getShowDate() {
		return showDate;
	}
	public void setShowDate(LocalDate date) {
		this.showDate = date;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public int getPriceTicket() {
		return priceTicket;
	}
	public void setPriceTicket(int priceTicket) {
		this.priceTicket = priceTicket;
	}
	
}
