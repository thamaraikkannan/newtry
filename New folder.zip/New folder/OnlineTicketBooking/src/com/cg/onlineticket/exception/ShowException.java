package com.cg.onlineticket.exception;

public class ShowException extends Exception {

	public ShowException(String message)
	{
		super(message);
	}
}
