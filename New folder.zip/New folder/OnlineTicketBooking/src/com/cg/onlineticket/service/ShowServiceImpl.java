package com.cg.onlineticket.service;

import java.util.List;

import com.capgemini.otb.dao.IShowDAO;
import com.capgemini.otb.dao.ShowDAOImpl;
import com.cg.onlineticket.bean.ShowBean;
import com.cg.onlineticket.exception.ShowException;

public class ShowServiceImpl implements IShowService
{
	IShowDAO dao = new ShowDAOImpl();
	@Override
	public List<ShowBean> viewAllDetails() throws ShowException 
	{
		return dao.viewAllDetails();
	}

	@Override
	public boolean updateSeats(String showName, int availableSeats) throws ShowException 
	{
		return dao.updateSeats(showName, availableSeats);
	}

}
