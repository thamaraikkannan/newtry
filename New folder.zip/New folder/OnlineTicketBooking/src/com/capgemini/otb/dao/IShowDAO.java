package com.capgemini.otb.dao;

import java.util.List;

import com.cg.onlineticket.bean.ShowBean;
import com.cg.onlineticket.exception.ShowException;

public interface IShowDAO {

	public List<ShowBean> viewAllDetails() throws ShowException;
	public boolean updateSeats(String showName,int availableSeats) throws ShowException;
}
