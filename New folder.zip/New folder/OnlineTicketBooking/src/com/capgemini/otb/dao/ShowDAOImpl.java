package com.capgemini.otb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.onlineticket.bean.ShowBean;
import com.cg.onlineticket.exception.ShowException;
import com.cg.onlineticket.util.DBConnection;


public class ShowDAOImpl implements IShowDAO {

	@Override
	public List<ShowBean> viewAllDetails() throws ShowException 
	{
		List<ShowBean> list = new ArrayList<ShowBean>();
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement pstmt = con.prepareStatement(QueryMapper.VIEWALL_QRY);
			ResultSet rst = pstmt.executeQuery();
			while(rst.next())
			{
				ShowBean bean = new ShowBean();
				bean.setShowName(rst.getString("showName"));
				bean.setLocation(rst.getString("location"));
				bean.setShowDate(rst.getDate("showDate").toLocalDate());
				bean.setPriceTicket(rst.getInt("priceTicket"));
				bean.setAvailableSeats(rst.getInt("avSeats"));
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			e.getMessage();
		}
		return list;
	}

	@Override
	public boolean updateSeats(String showName, int availableSeats) throws ShowException 
	{
		boolean flag=false;
        try{
        Connection con=DBConnection.getConnection();
        PreparedStatement pst=con.prepareStatement(QueryMapper.UPDATE_QRY);
        pst.setInt(1,availableSeats);
        pst.setString(2, showName);
        int result=pst.executeUpdate();
        if(result<=0)
        {
            flag=false;
        }
        else
        {
            flag=true;
        }
        }
        catch(SQLException e)
        {
            throw new ShowException("SQL exception"+e.getMessage());
        }
        catch(Exception e)
        {
            throw new ShowException(e.getMessage());
        }
		return flag;
	}

	
}
