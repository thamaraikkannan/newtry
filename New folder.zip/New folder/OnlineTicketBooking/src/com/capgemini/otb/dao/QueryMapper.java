package com.capgemini.otb.dao;

public interface QueryMapper {

	public static final String VIEWALL_QRY = "SELECT showName,location,showDate,priceTicket,avSeats FROM showDetails";
	public static final String UPDATE_QRY = "UPDATE showDetails SET avSeats=? WHERE showName=?";
}
